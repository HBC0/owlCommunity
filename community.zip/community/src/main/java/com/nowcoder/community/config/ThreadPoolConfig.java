package com.nowcoder.community.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * configuration 配置
 * enable scheduling 启用schedule
 * Enable Async 启用异步
 */

@Configuration
@EnableScheduling
@EnableAsync
public class ThreadPoolConfig {

}
