package com.nowcoder.community.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AlphaAspect {
//
//    @Pointcut("execution(* com.nowcoder.community.service.*.*(..))")
//    private void pointcut() {
//
//    }
//
//    @Before("pointcut()")
//    private void before() {
//        System.out.println("before");
//    }
//
//    @AfterReturning("pointcut()")
//    private void afterRetuning() {
//        System.out.println("afterRetuning");
//    }
//
//    @AfterThrowing("pointcut()")
//    private void afterThrowing() {
//        System.out.println("afterThrowing");
//    }
//
//    @Around("pointcut()")
//    private Object around(ProceedingJoinPoint joinPoint) throws Throwable {
//        System.out.println("around before!");
//        //调用目标组件的方法
//        Object object = joinPoint.proceed();
//        System.out.println("around after!");
//        return object;
//    }

}
