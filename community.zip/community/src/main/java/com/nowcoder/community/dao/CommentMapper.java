package com.nowcoder.community.dao;

import com.nowcoder.community.entity.Comment;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 数据访问组件Mapper
 */
@Mapper
public interface CommentMapper {

    /**
     *
     * @param entityType
     * @param entityId
     * @param offset  分页条件
     * @param limit   每页显示的限度
     * @return
     */
    List<Comment> selectCommentsByEntity(int entityType,int entityId,int offset,int limit);

    int selectCountByEntity(int entityType,int entityId);

    int insertComment(Comment comment);

    Comment selectCommentById(int id);

}
